const path = require('path');

module.exports = {
  // Local repo path
  repoPath: '/Users/kellymotley/Sites/family-emergency-preparedness-guide',

  // Automation root
  automationPath: __dirname,

  // Google OAuth credential files (never committed to git)
  clientSecretPath: path.join(__dirname, 'config', 'client_secret.json'),
  tokenPath: path.join(__dirname, 'config', 'token.json'),

  // YouTube playlist ID to watch (set this after running auth)
  // Get it from the playlist URL: youtube.com/playlist?list=PLAYLIST_ID
  playlistId: process.env.YOUTUBE_PLAYLIST_ID || '',

  // Anthropic API key (set in config/.env)
  anthropicApiKey: process.env.ANTHROPIC_API_KEY || '',

  // Dashboard
  port: 3000,

  // Cron schedule — default: 9am daily
  cronSchedule: '0 9 * * *',

  // Site base URL for sitemap
  siteUrl: 'https://emergencypreparednesschecklist.com',

  // SQLite database file
  dbPath: path.join(__dirname, 'queue.db'),
};
