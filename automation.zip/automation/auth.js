/**
 * Run this once: node auth.js
 * Opens a browser, you click Allow, token is saved to config/token.json
 */

const { google } = require('googleapis');
const fs = require('fs');
const http = require('http');
const url = require('url');
const open = require('open');
const config = require('./config');

const SCOPES = ['https://www.googleapis.com/auth/youtube.readonly'];

async function authenticate() {
  if (!fs.existsSync(config.clientSecretPath)) {
    console.error('❌ client_secret.json not found at', config.clientSecretPath);
    console.error('   Move your downloaded credentials file there first.');
    process.exit(1);
  }

  const credentials = JSON.parse(fs.readFileSync(config.clientSecretPath));
  const { client_id, client_secret, redirect_uris } = credentials.installed;

  const oauth2Client = new google.auth.OAuth2(client_id, client_secret, 'http://localhost:4242');

  // Check if we already have a valid token
  if (fs.existsSync(config.tokenPath)) {
    const token = JSON.parse(fs.readFileSync(config.tokenPath));
    oauth2Client.setCredentials(token);
    console.log('✅ Already authenticated. Token found at', config.tokenPath);
    return oauth2Client;
  }

  const authUrl = oauth2Client.generateAuthUrl({
    access_type: 'offline',
    scope: SCOPES,
  });

  console.log('\n🔐 Opening browser for Google authorization...\n');
  await open(authUrl);

  // Local server to catch the redirect
  return new Promise((resolve, reject) => {
    const server = http.createServer(async (req, res) => {
      const qs = new url.URL(req.url, 'http://localhost:4242').searchParams;
      const code = qs.get('code');

      if (!code) {
        res.end('No code received. Please try again.');
        server.close();
        return reject(new Error('No auth code received'));
      }

      res.end(`
        <html><body style="font-family:sans-serif;padding:40px;text-align:center">
          <h2>✅ Authorized successfully</h2>
          <p>You can close this tab and return to Terminal.</p>
        </body></html>
      `);
      server.close();

      try {
        const { tokens } = await oauth2Client.getToken(code);
        oauth2Client.setCredentials(tokens);
        fs.writeFileSync(config.tokenPath, JSON.stringify(tokens, null, 2));
        console.log('✅ Token saved to', config.tokenPath);
        resolve(oauth2Client);
      } catch (err) {
        reject(err);
      }
    });

    server.listen(4242, () => {
      console.log('   Waiting for Google redirect on port 4242...');
    });
  });
}

function getAuthClient() {
  if (!fs.existsSync(config.clientSecretPath) || !fs.existsSync(config.tokenPath)) {
    throw new Error('Not authenticated. Run: node auth.js');
  }

  const credentials = JSON.parse(fs.readFileSync(config.clientSecretPath));
  const { client_id, client_secret } = credentials.installed;
  const oauth2Client = new google.auth.OAuth2(client_id, client_secret, 'http://localhost:4242');
  const token = JSON.parse(fs.readFileSync(config.tokenPath));
  oauth2Client.setCredentials(token);

  // Auto-refresh token if expired
  oauth2Client.on('tokens', (tokens) => {
    if (tokens.refresh_token) {
      const current = JSON.parse(fs.readFileSync(config.tokenPath));
      fs.writeFileSync(config.tokenPath, JSON.stringify({ ...current, ...tokens }, null, 2));
    }
  });

  return oauth2Client;
}

module.exports = { authenticate, getAuthClient };

// Run directly: node auth.js
if (require.main === module) {
  authenticate()
    .then(() => { console.log('\n✅ Setup complete. You can now run: npm start'); process.exit(0); })
    .catch(err => { console.error('❌ Auth failed:', err.message); process.exit(1); });
}
