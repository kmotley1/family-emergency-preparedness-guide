const { google } = require('googleapis');
const { YoutubeTranscript } = require('youtube-transcript');
const { getAuthClient } = require('../auth');
const db = require('../db');
const config = require('../config');

/**
 * Fetch new videos from the configured playlist.
 * Returns array of { video_id, video_title, video_url, transcript }
 */
async function fetchNewVideos(playlistId) {
  const pid = playlistId || config.playlistId;
  if (!pid) throw new Error('No playlist ID configured. Set YOUTUBE_PLAYLIST_ID in config/.env');

  const auth = getAuthClient();
  const youtube = google.youtube({ version: 'v3', auth });

  console.log(`📋 Fetching playlist: ${pid}`);

  // Get all playlist items
  let items = [];
  let pageToken;

  do {
    const res = await youtube.playlistItems.list({
      part: 'snippet',
      playlistId: pid,
      maxResults: 50,
      pageToken,
    });

    items = items.concat(res.data.items);
    pageToken = res.data.nextPageToken;
  } while (pageToken);

  console.log(`   Found ${items.length} videos in playlist`);

  // Filter already processed
  const newItems = items.filter(item => {
    const videoId = item.snippet.resourceId.videoId;
    return !db.isVideoProcessed(videoId);
  });

  console.log(`   ${newItems.length} new videos to process`);

  if (!newItems.length) return [];

  // Fetch transcripts
  const results = [];

  for (const item of newItems) {
    const videoId = item.snippet.resourceId.videoId;
    const videoTitle = item.snippet.title;
    const videoUrl = `https://www.youtube.com/watch?v=${videoId}`;

    console.log(`\n📹 Processing: ${videoTitle}`);

    try {
      const transcriptItems = await YoutubeTranscript.fetchTranscript(videoId);
      const transcript = transcriptItems.map(t => t.text).join(' ').replace(/\s+/g, ' ').trim();

      if (!transcript || transcript.length < 200) {
        console.log(`   ⚠️  Transcript too short or unavailable — skipping`);
        db.markVideoProcessed(videoId);
        continue;
      }

      console.log(`   ✅ Transcript: ${transcript.length} characters`);

      results.push({ video_id: videoId, video_title: videoTitle, video_url: videoUrl, transcript });
      db.markVideoProcessed(videoId);

    } catch (err) {
      console.log(`   ❌ Transcript failed: ${err.message}`);
      // Don't mark processed — retry next run
    }
  }

  return results;
}

/**
 * Process a single video URL manually (for one-off imports from dashboard)
 */
async function fetchSingleVideo(videoUrl) {
  const videoIdMatch = videoUrl.match(/(?:v=|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
  if (!videoIdMatch) throw new Error('Invalid YouTube URL');

  const videoId = videoIdMatch[1];

  const auth = getAuthClient();
  const youtube = google.youtube({ version: 'v3', auth });

  const res = await youtube.videos.list({ part: 'snippet', id: videoId });
  const videoData = res.data.items[0];
  if (!videoData) throw new Error('Video not found');

  const videoTitle = videoData.snippet.title;

  console.log(`📹 Fetching transcript for: ${videoTitle}`);

  const transcriptItems = await YoutubeTranscript.fetchTranscript(videoId);
  const transcript = transcriptItems.map(t => t.text).join(' ').replace(/\s+/g, ' ').trim();

  return {
    video_id: videoId,
    video_title: videoTitle,
    video_url: videoUrl,
    transcript,
  };
}

module.exports = { fetchNewVideos, fetchSingleVideo };
