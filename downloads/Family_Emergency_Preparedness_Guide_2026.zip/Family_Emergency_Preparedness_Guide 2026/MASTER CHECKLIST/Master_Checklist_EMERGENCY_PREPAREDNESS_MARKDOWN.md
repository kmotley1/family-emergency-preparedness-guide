**FAMILY EMERGENCY PREPAREDNESS**

**MASTER CHECKLIST**

Complete Edition  ·  2026  ·  emergencypreparednesschecklist.com

| WHAT'S INSIDE →  Section 1  —  Foundation & Family Emergency Plan →  Section 2  —  Documents & Financial Records →  Section 3  —  The Go-Bag: Complete Equipment List →  Section 4  —  Vehicle Emergency Kit →  Section 5  —  Home Hardening & Shelter-in-Place →  Section 6  —  Medical, Medications & Special Needs →  Section 7  —  Food & Water Storage at Home →  Section 8  —  Communications & Information →  Section 9  —  Safety & Self-Defense →  Section 10 —  Community & Mutual Aid →  Section 11 —  Skills Development Tracker →  Section 12 —  Ongoing Maintenance Schedule |
| :---- |

*Print this. Post it. Work through it one section at a time.*

  **SECTION 1**  
  **Foundation & Family Emergency Plan**

  **FAMILY MEETING**

☐  Schedule and hold a family emergency meeting — in person, not over text

☐  Assign a primary decision-maker in case you lose communication

☐  Assign a backup decision-maker

☐  Every family member can explain the plan from memory

  **MEETING LOCATIONS**

☐  Primary meeting location (full address)  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Backup meeting location — away from your neighborhood (full address)  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Out-of-area rally point for extended displacement (full address)  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

  **COMMUNICATION PLAN**

☐  Designate one out-of-state relay contact  *–  easier to reach than local numbers during a disaster*

☐  Relay contact name & number  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Every family member has the relay contact memorized or written on a card

☐  Agree on text-first protocol  *–  texts go through when calls don't*

☐  Identify a backup method if phones are down  *–  walkie-talkie, neighbor, in-person rally point*

  **EVACUATION PLAN**

☐  Evacuation triggers — at what point do you leave  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Primary evacuation route (written out, not just GPS)  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Alternate evacuation route  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Evacuation destination  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

  **CHILDREN'S PLAN**

☐  Know your children's school emergency and early-release protocol

☐  Person authorized to pick up each child: Child / Authorized Person  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Child 1  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Child 2  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Child 3  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Each child knows their home address, a parent's cell number, and the relay contact

☐  Each child has a laminated emergency contacts card in their backpack

| NOTE  Print this plan. Laminate it. Give a copy to every adult in the household. A plan that only exists on your phone is useless when the phone is dead or lost. |
| :---- |

  **SECTION 2**  
  **Documents & Financial Records**

*Store in waterproof place.*

  **IDENTITY DOCUMENTS**

☐  Passports — all family members

☐  Driver's licenses / state IDs — all family members

☐  Birth certificates — all family members

☐  Social Security cards (or written numbers in sealed envelope)

☐  Naturalization certificates or green cards (if applicable)

☐  Marriage certificate

☐  Adoption records (if applicable)

☐  Military discharge papers / DD-214 (if applicable)

  **FINANCIAL & PROPERTY DOCUMENTS**

☐  Recent bank statements — account numbers and routing numbers noted

☐  Credit card account numbers and customer service numbers written down

☐  Investment and retirement account numbers and institutions

☐  Mortgage or lease agreement copy

☐  Vehicle titles

☐  Safe deposit box key and location noted

  **INSURANCE RECORDS**

☐  Homeowner's or renter's insurance — policy number and claims line

☐  Auto insurance — policy number and claims line

☐  Health insurance cards — all family members

☐  Life insurance — policy numbers and beneficiary information

  **MEDICAL RECORDS (PER FAMILY MEMBER)**

☐  Complete medication list with dosages, prescribing doctor, and pharmacy

☐  Allergy list — all family members

☐  Blood types written on a card  *–  add to the document bag*

☐  Vaccination records — all family members

☐  Primary care doctor name and number

☐  Specialist contact information

☐  Copies of any critical medical history or recent test results

  **EMERGENCY CASH RESERVE**

☐  Target: 30% of monthly take-home income in physical cash

☐  Monthly take-home:     \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  30% target: $  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Current cash total: $  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Bills in small denominations — mostly $1s, $5s, $10s, $20s

☐  Home safe (60–70% of reserve) — fireproof, waterproof, bolted down

☐  Safe location  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Go-bag cash ($200–500) — sealed in waterproof bag inside bag

☐  Vehicle cash ($100–200 per vehicle) — hidden securely in each vehicle

☐  Secondary location — portion at trusted person's home outside your household

  **PHYSICAL STORAGE & BACKUPS**

☐  All documents photocopied or photographed

☐  Stored in waterproof, fireproof document bag or pouch

☐  Physical photos of every family member printed and included

☐  10+ important phone numbers written in physical notebook

☐  Local area maps and evacuation routes printed

☐  Second copy stored off-site — trusted family, safe deposit box, or fireproof safe

| NOTE  During Hurricane Katrina and the 2021 Texas winter storm, ATMs ran dry within 24 hours and card networks went offline. The only money that worked was cash in hand. |
| :---- |

  **SECTION 3**  
  **The Go-Bag: Complete Equipment List**

*One bag per adult. Scaled down for children over 8\. Target weight: under 25% of the carrier's body weight. Refresh every 6 months.*

  **WATER & HYDRATION**

☐  Water — 1 gallon per person per day × 3 days minimum

☐  Water purification filter — LifeStraw, Sawyer Mini, or equivalent

☐  Water purification tablets — iodine or chlorine as backup

☐  Collapsible water container (2–4 liter) — for refilling en route

  **FOOD**

☐  Non-perishable food — 3-day supply per person, 1,800+ calories/day

☐  High-calorie emergency bars — Datrex or SOS brand  *–  compact, no cooking required*

☐  Protein bars or jerky — shelf-stable, high energy density

☐  Instant oatmeal, instant rice, or freeze-dried meals

☐  Hard candy and electrolyte packets — hydration and morale

☐  Manual can opener

☐  Lightweight utensils: spork, cup, small pot if space allows

  **SHELTER & WARMTH**

☐  Emergency Mylar blanket — one per person  *–  also works as a signaling mirror*

☐  Lightweight sleeping bag rated to 40°F or lower

☐  Compact sleeping pad or foam sit pad  *–  insulates from ground cold*

☐  Tarp (8×10 ft) or emergency bivy tent

☐  Paracord — 50–100 feet  *–  shelter rigging, clothesline, repairs*

☐  Waterproof matches in waterproof container

☐  Lighter — keep separate from matches

☐  Fire starter — ferro rod  *–  works when wet, lasts thousands of strikes*

☐  Hand warmers — at least 8 pairs  *–  also provide pain relief for injuries*

☐  Tarp stakes — 6 minimum

  **CLOTHING — PER PERSON**

☐  Moisture-wicking base layer top — synthetic or merino wool  *–  NOT cotton; cotton kills in cold and wet*

☐  Moisture-wicking base layer bottom — synthetic or merino wool

☐  Mid-layer: fleece jacket or lightweight down jacket  *–  packs small, retains warmth when compressed*

☐  Outer shell: waterproof, windproof jacket with hood

☐  Waterproof rain pants or shell pants

☐  Two pairs of wool or synthetic hiking socks  *–  cotton socks cause blisters and retain moisture*

☐  Moisture-wicking underwear — 2 pairs  *–  packed in resealable bag to stay dry*

☐  Sturdy, broken-in walking shoes or boots — waterproof preferred

☐  Warm hat covering ears — wool or fleece

☐  Gloves — waterproof outer shell with liner, or insulated work gloves

☐  Balaclava or neck gaiter  *–  adds warmth, protects face in wind and cold*

☐  Lightweight long-sleeve shirt — 2

☐  Durable quick-dry long pants

☐  Lightweight gaiters  *–  keeps debris and water out of boots during rough terrain*

☐  Bandana or buff  *–  multipurpose: dust protection, cooling, bandage, signaling*

☐  Sunglasses with UV protection  *–  eye protection from sun, wind, and debris*

☐  Sun hat or baseball cap — for warm weather or sunny evacuations

☐  Season-specific: balaclava and insulated pants (winter) OR sun shirt and cooling towel (summer)

  **LIGHT & COMMUNICATION**

☐  Flashlight (LED, waterproof) \+ 2 sets of extra batteries

☐  Headlamp \+ 2 sets of extra batteries  *–  keeps both hands free*

☐  Glow sticks — at least 4  *–  cold light, no fire risk, long duration*

☐  Battery or hand-crank NOAA emergency weather radio

☐  Portable phone charger — 20,000+ mAh, fully charged

☐  USB charging cables for all family devices

☐  Whistle — pealess design  *–  louder than shouting, works when voice fails*

☐  Small signal mirror

  **FIRST AID — FULL KIT**

☐  Adhesive bandages: assorted sizes including knuckle and fingertip styles

☐  Sterile gauze pads: 4×4 and 2×2, at least 6 of each

☐  Rolled gauze and elastic (ACE) bandage

☐  Medical tape — 1-inch and 2-inch rolls

☐  Antiseptic wipes

☐  Antibiotic ointment — Neosporin or equivalent

☐  Sterile eye wash and eye patches

☐  Blister treatment: moleskin and hydrocolloid bandages  *–  critical for foot travel*

☐  Tweezers, small scissors, needle-nose pliers

☐  SAM splint — moldable, works for all limb fractures

☐  Tourniquet — CAT or SOFTT-W  *–  learn to use it BEFORE you need it*

☐  Pressure dressing — Israeli bandage style

☐  Nitrile gloves — 4 pairs minimum

☐  CPR face shield

☐  Instant cold packs — 2

☐  Thermometer

☐  30-day supply of all prescription medications  *–  rotate monthly to keep fresh*

☐  Over-the-counter basics: pain reliever, antihistamine, antidiarrheal, antacid

☐  Oral rehydration salts (ORS) — for dehydration from illness or exertion

☐  Feminine hygiene products  *–  also effective as wound dressings*

☐  Physical first aid manual — printed book, not digital

  **TOOLS & UTILITIES**

☐  Multi-tool — Leatherman or equivalent  *–  knife, pliers, screwdrivers, saw*

☐  Fixed-blade knife in sheath — for heavy cutting tasks

☐  Duct tape — flatten the roll to save space

☐  Super glue — wound closure and field repairs

☐  Work gloves — heavy-duty, protects hands during debris work

☐  Zip ties — assorted sizes, 20+ count

☐  Heavy-duty contractor garbage bags — 3–5 count  *–  emergency shelter, rain cover, waste*

☐  Resealable plastic bags — gallon and quart sizes

☐  Permanent marker — labeling, leaving messages on surfaces

☐  Waterproof notepad and pen

☐  Small compass — no batteries needed

☐  Laminated local map and regional evacuation map

☐  Small pry bar or utility tool

  **DOCUMENTS & MONEY (GO-BAG COPY)**

☐  Waterproof bag: copies of IDs, passports, insurance, medical records, emergency contacts

☐  Physical photos of every family member — for identification if separated

☐  $200–500 in small bills — $1, $5, $10, $20 denominations

☐  Written list of account numbers, policy numbers, and key contact numbers

  **HYGIENE & SANITATION**

☐  Toothbrush and small tube of toothpaste

☐  Bar soap in sealed bag

☐  Hand sanitizer — 4 oz minimum

☐  Toilet paper — compressed camping roll

☐  Wet wipes or baby wipes — waterless bathing

☐  Deodorant

☐  Lip balm with SPF

☐  Sunscreen — SPF 30+

☐  Insect repellent — DEET or permethrin-treated clothing

☐  Small trowel — for latrine digging

☐  Waste disposal bags (WAG bags) — for sanitation without plumbing

  **FINAL GO-BAG CHECKS**

☐  Total bag weight:      lbs   (target: under 25% of your body weight)  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Weight test passed — put it on and walk one mile, adjust as needed

☐  Bag staged by the door or in designated grab-and-go location

☐  Every family member knows exactly where the bag is

☐  6-month refresh reminder set in calendar

☐  Last refreshed  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Next refresh due  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

| NOTE  Children over 8 can carry a small day pack with their own water bottle, snacks, a comfort item, and a laminated emergency contacts card. Pets need their own kit — see Section 6\. |
| :---- |

  **SECTION 4**  
  **Vehicle Emergency Kit**

*One kit per vehicle. Replenish anything used immediately. Check contents every 6 months.*

☐  Jumper cables or portable battery-powered jump starter

☐  Tire repair kit and portable 12V tire inflator

☐  Reflective emergency triangles or road flares — 3 minimum

☐  Fire extinguisher — ABC-rated, secured in cabin

☐  First aid kit — dedicated vehicle kit, not shared with go-bag

☐  Emergency cash — $100–200 in small bills, hidden securely

☐  Water — 1 gallon per passenger, stored in trunk

☐  Energy bars — 3-day supply per passenger

☐  Warm blanket — one per passenger, wool or Mylar

☐  Rain poncho — one per passenger

☐  Change of clothes — one set per passenger in sealed bag

☐  Work gloves

☐  Basic tools: adjustable wrench, screwdrivers, zip ties, duct tape

☐  Tow strap

☐  Folding shovel  *–  critical for snow, mud, or off-road situations*

☐  Sand, gravel, or cat litter — for traction on ice or mud

☐  Flashlight and extra batteries

☐  Phone charger cable and car adapter

☐  Printed maps — local and regional, in a waterproof bag

☐  Whistle and signal mirror

☐  Vehicle fuel policy: refill whenever tank drops below half

☐  Vehicle kit last checked  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

| REMINDER  Keep your tank above half as a default habit. In an evacuation, gas stations run out within hours and lines can stretch for miles. |
| :---- |

  **SECTION 5**  
  **Home Hardening & Shelter-in-Place**

*Small investments here prevent most common crisis scenarios. Work through these once, then maintain.*

  **SECURITY**

☐  Deadbolts on all exterior doors — Grade 1 or Grade 2 rated

☐  Strike plate upgraded to 3-inch screws — anchors into stud, not just door frame

☐  Door frame reinforcement kit on primary entry doors

☐  Security bar on all sliding glass doors

☐  Window locks functioning on all ground-floor windows

☐  Window security film on ground-floor windows  *–  delays forced entry significantly*

☐  Motion-activated exterior lights — front, back, and garage

☐  Video doorbell or peephole installed

☐  Alarm system or monitoring service active and tested

  **SAFE ROOM**

☐  Safe room identified — interior room, no windows, lowest floor

☐  Safe room location  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Safe room contains: water, flashlights, first aid kit, phone charger, written plan

  **UTILITY SHUTOFFS — EVERY ADULT MUST KNOW THESE**

☐  Main water shutoff location  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Water shutoff wrench stored nearby

☐  Main gas shutoff location  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Gas shutoff tool stored nearby

☐  Main electrical panel location  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  All circuit breakers clearly labeled

☐  Every adult in the household can shut off all three utilities without assistance

  **FIRE & CARBON MONOXIDE SAFETY**

☐  Fire extinguisher on each floor — kitchen, garage, primary living area

☐  Fire extinguisher service date  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Smoke detectors on every floor and in every bedroom — tested monthly

☐  Carbon monoxide detectors near all sleeping areas — tested monthly

☐  Detector batteries replaced annually  *–  set a calendar reminder*

☐  Escape ladder for upper-floor bedrooms — accessible and practiced

☐  Last fire drill  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

  **SHELTER-IN-PLACE SUPPLIES**

☐  Plastic sheeting and duct tape — for sealing rooms during air quality or chemical events

☐  N95 masks — minimum 2 per person

☐  Weather-band radio

☐  Battery lanterns or candles — 72+ hours of light

☐  Manual can opener accessible in kitchen

☐  Paper plates, cups, utensils — 3-day supply

  **SECTION 6**  
  **Medical, Medications & Special Needs**

*Complete this section for every family member. This is where most families are most underprepared.*

  **MEDICATIONS — ALL FAMILY MEMBERS**

☐  30-day supply of all prescription medications maintained at all times

☐  Rotate stock monthly — use oldest first, replace with new

☐  Written medication list: drug name, dosage, prescribing doctor, pharmacy

☐  Storage requirements noted — refrigeration, light-sensitive, temperature ranges

☐  Discussed emergency supply protocol with doctor — before a crisis occurs

☐  EpiPen or emergency injection device: confirmed in-date and accessible

☐  Insulin and supplies: backup supply secured, storage plan in place

☐  Asthma inhalers: backup supply on hand

☐  Mental health medications: supply secured, stability plan established

  **MEDICAL EQUIPMENT**

☐  CPAP or BiPAP: portable battery backup or travel machine acquired

☐  Oxygen concentrator or tanks: portable supply, duration calculated

☐  Hearing aids: backup batteries in go-bag, waterproof case

☐  Mobility aids: wheelchair, walker, cane — transport plan confirmed, backup if possible

☐  Blood glucose monitor and extra test strips

☐  Medical alert bracelet worn by all who need one

  **INFANTS & YOUNG CHILDREN**

☐  Formula — 2-week supply if bottle feeding

☐  Baby food — age-appropriate, 2-week supply

☐  Diapers and wipes — 2-week supply

☐  Baby carrier or sling — hands-free transport during evacuation

☐  Comfort item and small toy — reduces stress during displacement

☐  Children's fever reducer — acetaminophen and ibuprofen

☐  Children's antihistamine

☐  Pediatrician name and after-hours number  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

  **ELDERLY FAMILY MEMBERS**

☐  Mobility and transport needs assessed and planned for

☐  Their emergency documents are in your go-bag or with their own bag

☐  Local emergency registry for medical needs registered

☐  Registry name / number  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Backup caregiver identified and briefed  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

  **PETS**

☐  Pet ID tags current with phone number

☐  Pet microchip registered with current contact information

☐  Photo of each pet printed and stored in go-bag documents

☐  Pet carrier or leash staged near go-bags

☐  Pet food — 2-week supply in airtight container

☐  Collapsible water bowl for travel

☐  Pet medications — 30-day supply, rotated

☐  Pet vaccination records copy in document bag

☐  Evacuation destination confirmed as pet-friendly  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

| NOTE  Register with your local utility if any family member uses electricity-dependent medical equipment (CPAP, oxygen concentrator). Many utilities maintain priority restoration lists for medical customers. |
| :---- |

  **SECTION 7**  
  **Food & Water Storage at Home**

*Target: 2 weeks of food and water without leaving the house. This is shelter-in-place readiness.*

  **WATER STORAGE**

☐  Target: 1 gallon per person per day × 14 days minimum

☐  Family size  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Daily total needed (gallons)  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  2-week target (gallons)  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Current stored supply (gallons)  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Commercial bottled water or dedicated water storage containers

☐  Water stored away from direct sunlight, heat, and chemicals

☐  Rotation schedule: commercial bottles every 1–2 years, containers every 6–12 months

☐  Backup purification: filter \+ tablets \+ ability to boil

  **FOOD — PANTRY STAPLES**

☐  Canned proteins: tuna, chicken, beans, lentils — 2-week supply

☐  Canned vegetables and fruits — 2-week supply

☐  Grains: rice, oats, pasta, crackers — 2-week supply

☐  Peanut butter and nut butters — high calorie, no cooking required

☐  Honey — indefinite shelf life, antimicrobial properties

☐  Salt, sugar, cooking oil — basic cooking staples

☐  Powdered milk and powdered eggs — shelf stable, versatile

☐  Coffee, tea, comfort foods — morale matters in a sustained crisis

☐  Only stock foods your family actually eats — waste nothing

☐  Dietary restrictions or allergies to account for  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

  **COOKING WITHOUT POWER**

☐  Camp stove with sufficient fuel canisters — minimum 2-week supply

☐  OR: propane grill with full spare tank

☐  Second manual can opener — keep one in kitchen, one in go-bag

☐  Cast iron skillet — works on any heat source, nearly indestructible

☐  Fire starting capability: lighter, matches, fire starter

| REMINDER  NEVER use a propane stove, charcoal grill, or generator indoors. Carbon monoxide is odorless and kills in minutes. |
| :---- |

  **FOOD ROTATION SYSTEM**

☐  FIFO (First In, First Out) system in place: newest to back, oldest to front

☐  Expiration dates checked every 3 months

☐  Inventory list maintained — notebook or posted inside pantry door

  **SECTION 8**  
  **Communications & Information**

*Information is a survival resource. Know how to get it and share it when networks go down.*

  **EMERGENCY ALERTS**

☐  Wireless Emergency Alerts (WEA) enabled on all family phones

☐  Local county emergency alert system — signed up at  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  NOAA weather radio in home — programmed for local SAME code

☐  NOAA weather radio in go-bag — separate unit

☐  Know how to interpret Emergency Alert System (EAS) tones

  **WHEN PHONES ARE DOWN**

☐  FRS/GMRS walkie-talkies — one per adult household member

☐  Agreed channel  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Meeting point and check-in schedule established for no-phone scenarios

☐  Meeting point  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Check-in time  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Ham radio license being pursued  *–  highly recommended for extended outages — arrl.org*

  **IMPORTANT NUMBERS — WRITTEN DOWN, NOT JUST IN YOUR PHONE**

☐  All immediate family cell numbers  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Out-of-state relay contact  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Local emergency management  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Nearest hospital and urgent care  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Primary care doctor  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Pharmacy  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Gas, electric, and water utility emergency lines  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Insurance claims lines — home, auto, health  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Trusted neighbor  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Trusted out-of-area family member  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

  **INFORMATION SOURCES**

☐  Local emergency management website  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Local AM radio station for emergency broadcasts  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Battery or hand-crank AM/FM radio in home — to receive broadcasts without internet

☐  Printed copies of relevant emergency guides stored in binder

  **SECTION 9**  
  **Safety & Self-Defense**

*De-escalation is always the goal. Personal safety is built in layers — awareness, avoidance, then capability.*

  **SITUATIONAL AWARENESS**

☐  All family members understand and practice basic situational awareness

☐  Trusted contact notified when traveling to unfamiliar areas alone

☐  Family check-in protocol established for solo trips

☐  Everyone knows: if something feels wrong, leave — trust the instinct

  **NON-FIREARM OPTIONS**

☐  Pepper spray — legal in your jurisdiction, carried by adults who travel alone

☐  Personal alarm (130+ dB) — especially for family members who travel alone

☐  Tactical flashlight — bright enough to disorient, doubles as a defensive tool

☐  Door wedge alarm — for hotel stays and temporary housing

☐  Self-defense class style identified (Krav Maga, BJJ, boxing, workshop)  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  First session scheduled  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

  **FIREARMS (IF APPLICABLE)**

☐  Certified safety course completed before any firearm is handled — non-negotiable

☐  State and local storage, ownership, and carry laws reviewed

☐  Quick-access safe installed for home defense firearm

☐  Ammunition stored separately from firearms — critical if children are in the home

☐  Regular practice maintained — minimum monthly range session

☐  All adult household members trained and comfortable with the firearm

☐  Children taught the four rules of firearm safety — Eddie Eagle program or equivalent

  **FIRST AID & MEDICAL RESPONSE**

☐  Red Cross First Aid and CPR certification — at least one adult per household

☐  Stop the Bleed training completed — at least one adult per household  *–  bleedingcontrol.org*

☐  Certification expiration date  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Renewal scheduled  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Every family member age 10+ knows how to call 911 and clearly describe a location

  **SECTION 10**  
  **Community & Mutual Aid**

*Your neighbors are your most underused preparedness resource. Community is infrastructure.*

  **KNOW YOUR NEIGHBORS**

☐  Introduced yourself to immediate neighbors on each side and across the street

☐  Phone numbers exchanged with at least 4 neighbors

☐  Neighbor contacts  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Know who has a generator, medical training, or specific useful skills

☐  Know who may need help: elderly, disabled, single parents with young children

  **COMMUNITY RESOURCES**

☐  Local CERT program researched — community.fema.gov

☐  CERT training registered or completed

☐  Local mutual aid group or neighborhood emergency network  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Nearest Red Cross shelter  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Nearest community emergency resource point  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Local food bank or community resource contacts  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

  **WHAT YOU CAN CONTRIBUTE**

☐  Medical or first aid training

☐  Mechanical, electrical, or trade skills

☐  Generator or power generation equipment

☐  Extra water storage or filtration capacity

☐  Vehicle with towing capacity

☐  Radio communication equipment

☐  Food production — garden, fruit trees, livestock

☐  Your primary skill or resource to offer  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

  **SECTION 11**  
  **Skills Development Tracker**

*Pick two or three to start. Skills can't be taken from you, can't be frozen, and don't expire.*

| Skill | ☐ | Free Resource | Timeline |
| :---- | ----- | :---- | :---- |
| **Basic Gardening** | ☐ | mastergardener.org; YouTube: Epic Gardening | First harvest: 60–90 days |
| **Food Preservation: Canning** | ☐ | nchfp.uga.edu (free, research-based); local extension office | Basic skills: 1 weekend |
| **Food Preservation: Dehydrating** | ☐ | YouTube: The Purposeful Pantry | Learn in 1 afternoon |
| **Fermentation** | ☐ | YouTube: Farmhouse on Boone; culturesforhealth.com | First batch: 1–2 weeks |
| **Water Purification** | ☐ | wilderness.net; YouTube: 'purify water in the wild' | 30 minutes to learn basics |
| **Fire Starting Without Matches** | ☐ | YouTube: Primitive Technology; local REI Outdoor School | Basic: 1–2 practice sessions |
| **First Aid \+ CPR** | ☐ | redcross.org/take-a-class (free or low-cost community classes) | One 4–8 hour class |
| **Stop the Bleed / Tourniquet** | ☐ | bleedingcontrol.org — free online \+ in-person training | 2-hour class |
| **Sewing & Mending** | ☐ | YouTube: Evelyn Wood Sewing; local fabric store classes | Basic repairs: 2–4 hours |
| **Basic Carpentry & Repairs** | ☐ | YouTube: This Old House; Habitat for Humanity volunteer days | Basic repairs: 2–3 weekends |
| **Basic Plumbing** | ☐ | YouTube: 'fix a running toilet'; Home Depot free workshops | Basic: 1–2 projects |
| **Basic Electrical** | ☐ | YouTube: The Spruce; Home Depot free workshops | Basic: 1 weekend |
| **Basic Automotive Maintenance** | ☐ | YouTube: ChrisFix; AutoZone free guides; owner's manual | Core skills: 1 weekend |
| **Navigation: Map & Compass** | ☐ | YouTube: 'how to use a compass'; REI Expert Advice articles | Basic: 1–2 hours practice |
| **Firearms Safety & Handling** | ☐ | NRA Basic Pistol course; local certified range — required first | 1–2 day course |
| **Self-Defense (Krav Maga / BJJ)** | ☐ | Local gym — most offer free intro class; community workshops | Foundation: 3–6 months |
| **Foraging** | ☐ | Local guided walk (Meetup.com); iNaturalist app; regional field guide | Basic ID: 2–3 guided walks |
| **Emergency Shelter Construction** | ☐ | YouTube: 'emergency debris hut'; BSA merit badge guides | Basic: 1 practice day |
| **Ham Radio Operation** | ☐ | arrl.org study guides; HamStudy.org free practice exams | License: 1–2 weeks study |
| **Knot Tying** | ☐ | animatedknots.com — free visual guides for 100+ knots | 10 core knots: 1–2 hours |
| **Water Storage & Collection** | ☐ | FEMA water storage guide; YouTube: 'long-term water storage' | Setup: 1 afternoon |
| **Food Fermentation: Sourdough** | ☐ | YouTube: Binging with Babish; The Perfect Loaf (theperfectloaf.com) | First loaf: 1 week |
| **Backyard Chickens** | ☐ | Local 4-H program; YouTube: Justin Rhodes; The Chicken Whisperer | First flock: 1 season |

| NOTE  Don't try to learn everything. Pick the two skills most relevant to the most likely emergency in your area — weather events, power outages, or economic disruption — and go deep on those first. |
| :---- |

  **SECTION 12**  
  **Ongoing Maintenance Schedule**

*Preparedness is not a project with an end date. These reviews take under an hour and keep everything current.*

  **MONTHLY**

☐  Emergency cash — still at target? Top up if needed

☐  Prescription medications — within 30 days of running out? Request early refill now

☐  Phone charger in go-bag — plug in and recharge

☐  Smoke and carbon monoxide detectors — test monthly

  **EVERY 6 MONTHS  ·  SET REMINDERS FOR JANUARY 1 AND JULY 1**

☐  Go-bag food rotated — consume old stock, replace with fresh

☐  Go-bag water rotated — dump and refill, or replace sealed bottles

☐  All medication expiration dates checked

☐  Document copies updated — new ID photos, updated insurance cards

☐  All batteries tested — flashlights, headlamps, radio

☐  Phone charger tested in go-bag — confirm it still holds charge

☐  Clothing in go-bag checked — still fits? Still season-appropriate?

☐  Go-bag weighed — still manageable for the carrier?

☐  Cash reserve counted — still at target? Rotate bills held 18+ months

☐  Contact information reviewed — any changes to relay contact or neighbors?

☐  Vehicle emergency kit restocked

☐  Fire extinguishers inspected — pressure gauge in green zone?

☐  Last 6-month refresh completed  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

  **ANNUALLY  ·  SET A REMINDER FOR THE SAME DATE EACH YEAR**

☐  Run through the full emergency plan verbally with every family member

☐  Ask each person: 'What would you do if you couldn't reach anyone?'

☐  Meeting locations and evacuation routes reviewed for any changes

☐  Evacuation triggers reviewed — still appropriate for your current situation?

☐  Children's school pickup protocol confirmed current

☐  First Aid and CPR certification expiration checked — renew if within 3 months

☐  Certification expiration  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Renewal scheduled  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  New skill identified to learn this year

☐  Skill for this year  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

☐  Home fire drill completed

☐  Smoke and CO detector batteries replaced

☐  Annual review completed  \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

| REMINDER  Set three recurring calendar reminders right now: the 1st of every month, January 1st, July 1st, and one annual date. The families who stay prepared are the ones who automated the reminders. |
| :---- |

  **You have done more than 95% of families will ever do.**  

emergencypreparednesschecklist.com